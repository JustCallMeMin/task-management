const UserRoles = Object.freeze({
    ADMIN: "admin",
    MANAGER: "manager",
    EMPLOYEE: "employee"
});

module.exports = UserRoles;