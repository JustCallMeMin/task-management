const ErrorMessages = Object.freeze({
    INVALID_CREDENTIALS: "Invalid username or password.",
    UNAUTHORIZED: "You are not authorized to perform this action.",
    NOT_FOUND: "Requested resource not found.",
    SERVER_ERROR: "Something went wrong. Please try again later."
});

module.exports = ErrorMessages;