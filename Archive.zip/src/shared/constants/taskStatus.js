const TaskStatus = Object.freeze({
    PENDING: "pending",
    IN_PROGRESS: "in_progress",
    COMPLETED: "completed",
    CANCELED: "canceled"
});

module.exports = TaskStatus;