class AuthConfig {
    constructor() {
        this.secret = process.env.AUTH_SECRET;
        this.expiresIn = "1h";
    }

    getSecret() {
        return this.secret;
    }

    getExpiration() {
        return this.expiresIn;
    }
}

module.exports = new AuthConfig();