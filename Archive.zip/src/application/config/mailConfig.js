class MailConfig {
    constructor() {
        this.smtpHost = process.env.SMTP_HOST;
        this.smtpPort = process.env.SMTP_PORT;
        this.user = process.env.SMTP_USER;
        this.pass = process.env.SMTP_PASS;
    }

    getSMTP() {
        return {
            host: this.smtpHost,
            port: this.smtpPort,
            auth: {
                user: this.user,
                pass: this.pass
            }
        };
    }
}

module.exports = new MailConfig();