class DeleteCommentUseCase {
    constructor(commentRepository) {
        this.commentRepository = commentRepository;
    }

    async execute(commentId, userId) {
        const comment = await this.commentRepository.findById(commentId);
        if (!comment) {
            throw new Error("Bình luận không tồn tại.");
        }

        // Kiểm tra quyền xóa bình luận
        if (comment.userId !== userId) {
            throw new Error("Bạn không thể xóa bình luận này!");
        }

        return await this.commentRepository.deleteComment(commentId);
    }
}

module.exports = DeleteCommentUseCase;