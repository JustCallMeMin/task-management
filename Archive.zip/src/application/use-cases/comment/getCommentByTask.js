class GetCommentsByTaskUseCase {
    constructor(commentRepository) {
        this.commentRepository = commentRepository;
    }

    async execute(taskId) {
        return await this.commentRepository.getCommentsByTask(taskId);
    }
}

module.exports = GetCommentsByTaskUseCase;