class AddCommentUseCase {
    constructor(commentRepository, taskRepository) {
        this.commentRepository = commentRepository;
        this.taskRepository = taskRepository;
    }

    async execute(taskId, userId, content, userRoles) {
        const task = await this.taskRepository.findById(taskId);
        if (!task) {
            throw new Error("Công việc không tồn tại.");
        }

        // Kiểm tra quyền bình luận
        if (task.assignedUserId !== userId && !userRoles.includes("Manager")) {
            throw new Error("Bạn không thể bình luận vào công việc này!");
        }

        return await this.commentRepository.createComment(taskId, userId, content);
    }
}

module.exports = AddCommentUseCase;