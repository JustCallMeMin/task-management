class UpdateUserUseCase {
    constructor(userRepository) {
        this.userRepository = userRepository;
    }

    async execute(userId, userData) {
        const user = await this.userRepository.findById(userId);
        if (!user) {
            throw new Error("Người dùng không tồn tại.");
        }
        return await this.userRepository.updateUser(userId, userData);
    }
}

module.exports = UpdateUserUseCase;