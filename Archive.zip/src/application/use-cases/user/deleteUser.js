class DeleteUserUseCase {
    constructor(userRepository) {
        this.userRepository = userRepository;
    }

    async execute(userId) {
        const user = await this.userRepository.findById(userId);
        if (!user) {
            throw new Error("Người dùng không tồn tại.");
        }
        return await this.userRepository.deleteUser(userId);
    }
}

module.exports = DeleteUserUseCase;