class DeleteTaskUseCase {
    constructor(taskRepository) {
        this.taskRepository = taskRepository;
    }

    async execute(taskId, userId) {
        const task = await this.taskRepository.findById(taskId);
        if (!task) {
            throw new Error("Công việc không tồn tại.");
        }

        if (task.assignedUserId !== userId) {
            throw new Error("Bạn không có quyền xóa công việc này!");
        }

        return await this.taskRepository.deleteTask(taskId);
    }
}

module.exports = DeleteTaskUseCase;