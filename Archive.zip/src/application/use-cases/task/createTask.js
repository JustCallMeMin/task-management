class CreateTaskUseCase {
    constructor(taskRepository) {
        this.taskRepository = taskRepository;
    }

    async execute(userId, taskData) {
        return await this.taskRepository.createTask(userId, taskData);
    }
}

module.exports = CreateTaskUseCase;