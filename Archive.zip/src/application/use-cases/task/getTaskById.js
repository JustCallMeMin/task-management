class GetTaskByIdUseCase {
    constructor(taskRepository) {
        this.taskRepository = taskRepository;
    }

    async execute(taskId, userId) {
        return await this.taskRepository.getTaskById(taskId, userId);
    }
}

module.exports = GetTaskByIdUseCase;