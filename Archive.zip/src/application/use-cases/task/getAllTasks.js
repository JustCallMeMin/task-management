class GetAllTasksUseCase {
    constructor(taskRepository) {
        this.taskRepository = taskRepository;
    }

    async execute(userId) {
        return await this.taskRepository.getAllTasks(userId);
    }
}

module.exports = GetAllTasksUseCase;