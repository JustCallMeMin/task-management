class UpdateTaskUseCase {
    constructor(taskRepository) {
        this.taskRepository = taskRepository;
    }

    async execute(taskId, userId, taskData) {
        const task = await this.taskRepository.findById(taskId);
        if (!task) {
            throw new Error("Công việc không tồn tại.");
        }

        if (task.assignedUserId !== userId) {
            throw new Error("Bạn không có quyền chỉnh sửa công việc này!");
        }

        return await this.taskRepository.updateTask(taskId, taskData);
    }
}

module.exports = UpdateTaskUseCase;