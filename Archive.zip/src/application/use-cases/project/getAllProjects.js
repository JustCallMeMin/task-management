class GetAllProjectsUseCase {
    constructor(projectRepository) {
        this.projectRepository = projectRepository;
    }

    async execute(userId) {
        return await this.projectRepository.getAllProjects(userId);
    }
}

module.exports = GetAllProjectsUseCase;