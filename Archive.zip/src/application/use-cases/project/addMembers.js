class AddMembersUseCase {
    constructor(projectRepository) {
        this.projectRepository = projectRepository;
    }

    async execute(projectId, members) {
        return await this.projectRepository.addMembers(projectId, members);
    }
}

module.exports = AddMembersUseCase;