class DeleteProjectsUseCase {
    constructor(projectRepository) {
        this.projectRepository = projectRepository;
    }

    async execute(projectIds) {
        return await this.projectRepository.deleteProjects(projectIds);
    }
}

module.exports = DeleteProjectsUseCase;