class GetProjectByIdUseCase {
    constructor(projectRepository) {
        this.projectRepository = projectRepository;
    }

    async execute(projectId) {
        return await this.projectRepository.getProjectById(projectId);
    }
}

module.exports = GetProjectByIdUseCase;