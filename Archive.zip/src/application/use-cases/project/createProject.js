class CreateProjectUseCase {
    constructor(projectRepository) {
        this.projectRepository = projectRepository;
    }

    async execute(userId, projectData) {
        return await this.projectRepository.createProject(userId, projectData);
    }
}

module.exports = CreateProjectUseCase;