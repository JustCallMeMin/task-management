class RemoveMembersUseCase {
    constructor(projectRepository) {
        this.projectRepository = projectRepository;
    }

    async execute(projectId, userIds) {
        return await this.projectRepository.removeMembers(projectId, userIds);
    }
}

module.exports = RemoveMembersUseCase;