class UpdateProjectUseCase {
    constructor(projectRepository) {
        this.projectRepository = projectRepository;
    }

    async execute(projectId, projectData) {
        return await this.projectRepository.updateProject(projectId, projectData);
    }
}

module.exports = UpdateProjectUseCase;