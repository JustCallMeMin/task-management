class ResetPasswordUseCase {
    constructor(authRepository) {
        this.authRepository = authRepository;
    }

    async execute(resetCode, newPassword) {
        return await this.authRepository.resetPassword(resetCode, newPassword);
    }
}

module.exports = ResetPasswordUseCase;