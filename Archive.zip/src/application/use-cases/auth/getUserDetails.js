class GetUserDetailsUseCase {
    constructor(authRepository) {
        this.authRepository = authRepository;
    }

    async execute(userId) {
        const user = await this.authRepository.getUserDetails(userId);
        if (!user) {
            throw new Error("Người dùng không tồn tại.");
        }
        return user;
    }
}

module.exports = GetUserDetailsUseCase;