class LogoutUseCase {
    constructor(authRepository) {
        this.authRepository = authRepository;
    }

    async execute(user) {
        return await this.authRepository.logout(user);
    }
}

module.exports = LogoutUseCase;