const CreateProjectUseCase = require('../../application/use-cases/project/createProject');
const AddMembersUseCase = require('../../application/use-cases/project/addMembers');
const RemoveMembersUseCase = require('../../application/use-cases/project/removeMembers');
const UpdateProjectUseCase = require('../../application/use-cases/project/updateProject');
const DeleteProjectsUseCase = require('../../application/use-cases/project/deleteProjects');
const GetAllProjectsUseCase = require('../../application/use-cases/project/getAllProjects');
const GetProjectByIdUseCase = require('../../application/use-cases/project/getProjectById');
const projectRepository = require('../../infrastructure/repositories/project.repository');
const { successResponse, errorResponse, formatProjectsResponse, formatProjectResponse } = require("../../shared/utils/response");

class ProjectController {
    static async createOrganizationProject(req, res) {
        try {
            const createProject = new CreateProjectUseCase(projectRepository);
            const project = await createProject.execute(req.user.id, req.body);
            return successResponse(res, project, "Dự án được tạo thành công.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async addMembers(req, res) {
        try {
            const { projectId } = req.params;
            const { members } = req.body;
            const addMembers = new AddMembersUseCase(projectRepository);
            const result = await addMembers.execute(projectId, members);
            return successResponse(res, result, "Thành viên đã được thêm vào dự án.");
        } catch (error) {
            return errorResponse(res, error);
        }
    }

    static async removeMembers(req, res) {
        try {
            const { projectId } = req.params;
            const { userIds } = req.body;
            const removeMembers = new RemoveMembersUseCase(projectRepository);
            const result = await removeMembers.execute(projectId, userIds);
            return successResponse(res, result, "Thành viên đã được xóa khỏi dự án.");
        } catch (error) {
            return errorResponse(res, error);
        }
    }

    static async updateProject(req, res) {
        try {
            const { projectId } = req.params;
            const updateProject = new UpdateProjectUseCase(projectRepository);
            const project = await updateProject.execute(projectId, req.body);
            return successResponse(res, project, "Dự án được cập nhật thành công.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async deleteProjects(req, res) {
        try {
            const { projectIds } = req.body;
            const deleteProjects = new DeleteProjectsUseCase(projectRepository);
            const result = await deleteProjects.execute(projectIds);
            return successResponse(res, result, "Dự án đã được xóa thành công.");
        } catch (error) {
            return errorResponse(res, error);
        }
    }

    static async getAllProjects(req, res) {
        try {
            const getAllProjects = new GetAllProjectsUseCase(projectRepository);
            const projects = await getAllProjects.execute(req.user.id);
            return successResponse(res, formatProjectsResponse(projects), "Danh sách dự án.");
        } catch (error) {
            return errorResponse(res, error);
        }
    }

    static async getProjectById(req, res) {
        try {
            const { projectId } = req.params;
            const getProjectById = new GetProjectByIdUseCase(projectRepository);
            const project = await getProjectById.execute(projectId);
            return successResponse(res, formatProjectResponse(project), "Thông tin dự án.");
        } catch (error) {
            return errorResponse(res, error);
        }
    }
}

module.exports = ProjectController;