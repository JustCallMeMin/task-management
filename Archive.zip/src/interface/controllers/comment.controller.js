const AddCommentUseCase = require('../../application/use-cases/comment/addComment');
const GetCommentsByTaskUseCase = require('../../application/use-cases/comment/getCommentByTask');
const DeleteCommentUseCase = require('../../application/use-cases/comment/deleteComment');
const commentRepository = require('../../infrastructure/repositories/comment.repository');
const taskRepository = require('../../infrastructure/repositories/task.repository');
const { successResponse, errorResponse } = require("../../shared/utils/response");

class CommentController {
    static async addComment(req, res) {
        try {
            const { taskId, content } = req.body;
            const addComment = new AddCommentUseCase(commentRepository, taskRepository);
            const comment = await addComment.execute(taskId, req.user.id, content, req.user.roles);
            return successResponse(res, comment, "Thêm bình luận thành công!");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async getCommentsByTask(req, res) {
        try {
            const { taskId } = req.params;
            const getCommentsByTask = new GetCommentsByTaskUseCase(commentRepository);
            const comments = await getCommentsByTask.execute(taskId);
            return successResponse(res, comments, "Danh sách bình luận");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async deleteComment(req, res) {
        try {
            const { commentId } = req.params;
            const deleteComment = new DeleteCommentUseCase(commentRepository);
            await deleteComment.execute(commentId, req.user.id);
            return successResponse(res, null, "Xóa bình luận thành công!");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }
}

module.exports = CommentController;