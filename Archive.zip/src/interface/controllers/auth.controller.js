const GetUserDetailsUseCase = require('../../application/use-cases/auth/getUserDetails');
const ForgotPasswordUseCase = require('../../application/use-cases/auth/forgotPassword');
const ResetPasswordUseCase = require('../../application/use-cases/auth/resetPassword');
const LogoutUseCase = require('../../application/use-cases/auth/logout');
const RegisterUseCase = require('../../application/use-cases/auth/register');
const LoginUseCase = require('../../application/use-cases/auth/login');
const authRepository = require('../../infrastructure/repositories/auth.repository');
const { successResponse, errorResponse, formatAuthResponse } = require("../../shared/utils/response");

class AuthController {
    static async getMe(req, res) {
        try {
            if (!req.user) {
                return errorResponse(res, "Không tìm thấy thông tin người dùng.", 401);
            }
            const getUserDetails = new GetUserDetailsUseCase(authRepository);
            const user = await getUserDetails.execute(req.user.id);
            return successResponse(res, formatAuthResponse(user), "Lấy thông tin người dùng thành công.");
        } catch (error) {
            return errorResponse(res, "Lỗi máy chủ.", 500);
        }
    }

    static async forgotPassword(req, res) {
        try {
            const { email } = req.body;
            const forgotPassword = new ForgotPasswordUseCase(authRepository);
            await forgotPassword.execute(email);
            res.status(200).json({ message: 'Email đặt lại mật khẩu đã được gửi' });
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    }

    static async resetPassword(req, res) {
        try {
            const { resetCode, newPassword } = req.body;
            const resetPassword = new ResetPasswordUseCase(authRepository);
            await resetPassword.execute(resetCode, newPassword);
            res.status(200).json({ message: "Mật khẩu đã được cập nhật" });
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    }

    static async logout(req, res) {
        try {
            const logout = new LogoutUseCase(authRepository);
            await logout.execute(req.user);
            res.status(200).json({ message: 'Đăng xuất thành công' });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async register(req, res) {
        try {
            const register = new RegisterUseCase(authRepository);
            const user = await register.execute(req.body);
            res.status(201).json(user);
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    }

    static async login(req, res) {
        try {
            const { email, password } = req.body;
            const login = new LoginUseCase(authRepository);
            const { token, refreshToken, user } = await login.execute(email, password);
            res.status(200).json({ token, refreshToken, user });
        } catch (error) {
            res.status(401).json({ error: error.message });
        }
    }
}

module.exports = AuthController;