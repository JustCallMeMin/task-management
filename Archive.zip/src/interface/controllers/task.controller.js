const CreateTaskUseCase = require('../../application/use-cases/task/createTask');
const UpdateTaskUseCase = require('../../application/use-cases/task/updateTask');
const DeleteTaskUseCase = require('../../application/use-cases/task/deleteTask');
const GetAllTasksUseCase = require('../../application/use-cases/task/getAllTasks');
const GetTaskByIdUseCase = require('../../application/use-cases/task/getTaskById');
const taskRepository = require('../../infrastructure/repositories/task.repository');
const { successResponse, errorResponse } = require("../../shared/utils/response");

class TaskController {
    static async createTask(req, res) {
        try {
            const createTask = new CreateTaskUseCase(taskRepository);
            const task = await createTask.execute(req.user.id, req.body);
            return successResponse(res, task, "Công việc được tạo thành công.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async updateTask(req, res) {
        try {
            const { taskId } = req.params;
            const updateTask = new UpdateTaskUseCase(taskRepository);
            const task = await updateTask.execute(taskId, req.user.id, req.body);
            return successResponse(res, task, "Công việc được cập nhật thành công.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async deleteTask(req, res) {
        try {
            const { taskId } = req.params;
            const deleteTask = new DeleteTaskUseCase(taskRepository);
            await deleteTask.execute(taskId, req.user.id);
            return successResponse(res, null, "Công việc đã bị xóa.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async getAllTasks(req, res) {
        try {
            const getAllTasks = new GetAllTasksUseCase(taskRepository);
            const tasks = await getAllTasks.execute(req.user.id);
            return successResponse(res, tasks, "Danh sách công việc.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async getTaskById(req, res) {
        try {
            const { taskId } = req.params;
            const getTaskById = new GetTaskByIdUseCase(taskRepository);
            const task = await getTaskById.execute(taskId, req.user.id);
            return successResponse(res, task, "Thông tin công việc.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }
}

module.exports = TaskController;