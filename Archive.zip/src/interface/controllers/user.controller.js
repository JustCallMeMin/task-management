const GetUserByIdUseCase = require('../../application/use-cases/user/getUserById');
const GetAllUsersUseCase = require('../../application/use-cases/user/getAllUsers');
const UpdateUserUseCase = require('../../application/use-cases/user/updateUser');
const DeleteUserUseCase = require('../../application/use-cases/user/deleteUser');
const userRepository = require('../../infrastructure/repositories/user.repository');
const { successResponse, errorResponse } = require("../../shared/utils/response");

class UserController {
    static async getUserById(req, res) {
        try {
            const getUserById = new GetUserByIdUseCase(userRepository);
            const user = await getUserById.execute(req.params.userId);
            return successResponse(res, user, "Thông tin người dùng.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async getAllUsers(req, res) {
        try {
            const getAllUsers = new GetAllUsersUseCase(userRepository);
            const users = await getAllUsers.execute();
            return successResponse(res, users, "Danh sách người dùng.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async updateUser(req, res) {
        try {
            const updateUser = new UpdateUserUseCase(userRepository);
            const updatedUser = await updateUser.execute(req.params.userId, req.body);
            return successResponse(res, updatedUser, "Người dùng được cập nhật thành công.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }

    static async deleteUser(req, res) {
        try {
            const deleteUser = new DeleteUserUseCase(userRepository);
            await deleteUser.execute(req.params.userId);
            return successResponse(res, null, "Người dùng đã bị xóa.");
        } catch (error) {
            return errorResponse(res, error.message);
        }
    }
}

module.exports = UserController;