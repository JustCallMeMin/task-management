const { Sequelize } = require('sequelize');

class DatabaseConfig {
    constructor() {
        this.sequelize = new Sequelize(
            process.env.DB_NAME,
            process.env.DB_USER,
            process.env.DB_PASS,
            {
                host: process.env.DB_HOST,
                dialect: 'mysql'
            }
        );
    }

    getInstance() {
        return this.sequelize;
    }
}

module.exports = new DatabaseConfig();