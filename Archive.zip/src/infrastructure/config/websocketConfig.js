const { Server } = require("socket.io");
const http = require("http");

class WebSocketConfig {
    constructor() {
        this.server = http.createServer();
        this.io = null;
        this.port = process.env.WS_PORT || 3001;
    }

    init() {
        if (!this.io) {
            this.io = new Server(this.server, {
                cors: {
                    origin: "*",
                    methods: ["GET", "POST"]
                }
            });

            // Gọi các handlers từ module riêng
            require("../websocket/websocketHandlers")(this.io);

            this.server.listen(this.port, () => {
                console.log(`🚀 WebSocket Server running on port ${this.port}.`);
            });
        }
    }

    getInstance() {
        if (!this.io) {
            throw new Error("WebSocket server chưa được khởi tạo!");
        }
        return this.io;
    }
}

module.exports = new WebSocketConfig();