const { UserModel } = require("../../infrastructure/database/models/user.model"); // ORM Model

class UserRepository {
    async findById(userId) {
        return await UserModel.findByPk(userId);
    }

    async getAllUsers() {
        return await UserModel.findAll();
    }

    async updateUser(userId, userData) {
        return await UserModel.update(userData, { where: { id: userId } });
    }

    async deleteUser(userId) {
        return await UserModel.destroy({ where: { id: userId } });
    }
}

module.exports = new UserRepository();