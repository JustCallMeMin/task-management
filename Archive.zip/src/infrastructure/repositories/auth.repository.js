const { UserModel } = require("../../infrastructure/database/models/user.model");
const { RoleModel } = require("../../infrastructure/database/models/role.model");
const { PermissionModel } = require("../../infrastructure/database/models/permission.model");

class AuthRepository {
    async getUserById(userId) {
        return await UserModel.findOne({
            where: { userId },
            include: [{ model: RoleModel, as: "Roles" }]
        });
    }

    async getUserPermissions(roleNames) {
        const roles = await RoleModel.findAll({
            where: { roleName: roleNames },
            include: [{ model: PermissionModel, as: "Permissions" }]
        });
        return roles.flatMap(role => role.Permissions.map(perm => perm.permissionName));
    }
}

module.exports = new AuthRepository();