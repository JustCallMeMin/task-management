const { TaskModel } = require("../../infrastructure/database/models/task.model"); // ORM Model

class TaskRepository {
    async createTask(userId, taskData) {
        return await TaskModel.create({ ...taskData, assignedUserId: userId });
    }

    async findById(taskId) {
        return await TaskModel.findByPk(taskId);
    }

    async updateTask(taskId, taskData) {
        return await TaskModel.update(taskData, { where: { id: taskId } });
    }

    async deleteTask(taskId) {
        return await TaskModel.destroy({ where: { id: taskId } });
    }

    async getAllTasks(userId) {
        return await TaskModel.findAll({ where: { assignedUserId: userId } });
    }

    async getTaskById(taskId, userId) {
        return await TaskModel.findOne({ where: { id: taskId, assignedUserId: userId } });
    }
}

module.exports = new TaskRepository();