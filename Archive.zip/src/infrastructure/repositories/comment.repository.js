const { CommentModel } = require("../../infrastructure/database/models/comment.model"); // ORM Model

class CommentRepository {
    async createComment(taskId, userId, content) {
        return await CommentModel.create({ taskId, userId, content });
    }

    async getCommentsByTask(taskId) {
        return await CommentModel.findAll({ where: { taskId }, order: [['createdAt', 'DESC']] });
    }

    async findById(commentId) {
        return await CommentModel.findByPk(commentId);
    }

    async deleteComment(commentId) {
        return await CommentModel.destroy({ where: { id: commentId } });
    }
}

module.exports = new CommentRepository();