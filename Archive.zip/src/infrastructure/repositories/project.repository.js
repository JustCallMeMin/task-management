const { ProjectModel } = require("../../infrastructure/database/models/project.model"); // ORM Model

class ProjectRepository {
    async createProject(userId, projectData) {
        return await ProjectModel.create({ ...projectData, ownerId: userId });
    }

    async addMembers(projectId, members) {
        const project = await ProjectModel.findByPk(projectId);
        if (!project) throw new Error("Dự án không tồn tại.");
        return await project.addMembers(members); // Nếu dùng Sequelize Many-to-Many
    }

    async removeMembers(projectId, userIds) {
        const project = await ProjectModel.findByPk(projectId);
        if (!project) throw new Error("Dự án không tồn tại.");
        return await project.removeMembers(userIds);
    }

    async updateProject(projectId, projectData) {
        const project = await ProjectModel.findByPk(projectId);
        if (!project) throw new Error("Dự án không tồn tại.");
        return await project.update(projectData);
    }

    async deleteProjects(projectIds) {
        return await ProjectModel.destroy({ where: { id: projectIds } });
    }

    async getAllProjects(userId) {
        return await ProjectModel.findAll({ where: { ownerId: userId } });
    }

    async getProjectById(projectId) {
        return await ProjectModel.findByPk(projectId);
    }
}

module.exports = new ProjectRepository();