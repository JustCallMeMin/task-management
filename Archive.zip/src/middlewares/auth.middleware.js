const jwt = require("jsonwebtoken");
const authRepository = require("../infrastructure/repositories/auth.repository");
require("dotenv").config();

const authenticate = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(" ")[1];

        if (!token) {
            return res.status(401).json({ message: "Bạn chưa đăng nhập. Vui lòng đăng nhập!" });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        if (!decoded.userId) {
            return res.status(401).json({ message: "Token không hợp lệ!" });
        }

        const user = await authRepository.getUserById(decoded.userId);
        if (!user) {
            return res.status(401).json({ message: "Tài khoản không tồn tại hoặc đã bị xóa!" });
        }

        // Lấy danh sách tên vai trò từ user
        req.user = {
            id: user.userId,
            roles: user.Roles.map(role => role.roleName)
        };

        next();
    } catch (error) {
        console.log("❌ Lỗi xác thực:", error);
        return res.status(403).json({ message: "Phiên đăng nhập không hợp lệ hoặc đã hết hạn!" });
    }
};

const authorize = (permissions) => {
    return async (req, res, next) => {
        try {
            if (!req.user || !req.user.roles) {
                return res.status(403).json({ message: "Forbidden: Bạn không có quyền truy cập!" });
            }

            // Sử dụng repository để lấy quyền
            const permissionNames = await authRepository.getUserPermissions(req.user.roles);

            if (!permissions.some(perm => permissionNames.includes(perm))) {
                return res.status(403).json({ message: "Forbidden: Bạn không có quyền truy cập!" });
            }
            next();
        } catch (error) {
            console.log("❌ Lỗi phân quyền:", error);
            return res.status(500).json({ message: "Internal server error" });
        }
    };
};

module.exports = { authenticate, authorize };